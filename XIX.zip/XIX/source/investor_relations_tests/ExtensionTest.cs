﻿using IR;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;
using System.Collections.Generic;
using System.Xml.Linq;
using System.Linq;

namespace investor_relations_tests
{
    
    
    /// <summary>
    ///This is a test class for ExtensionTest and is intended
    ///to contain all ExtensionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ExtensionTest {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext {
            get {
                return testContextInstance;
            }
            set {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for RecurseInner
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\jjohnson\\Documents\\GitHub\\XIX\\source\\src", "/")]
        [UrlToTest("http://localhost:56718/")]
        public void RecurseInnerTest() {
            Exception exception = new Exception("test 123", new ArgumentException("inner 456", new ArgumentOutOfRangeException("inner 789")));
            IEnumerable<Exception> expected = new[] { new Exception("test 123"), new ArgumentException("inner 456"), new ArgumentOutOfRangeException("inner 789") };
            IEnumerable<Exception> actual;
            actual = Extension.RecurseInner(exception);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for ToEnumerable
        ///</summary>
        public void ToEnumerableTestHelper<T>() {
            T i = default(T);
            IEnumerable<T> expected = (new[] { i }).ToArray().AsEnumerable();
            IEnumerable<T> actual;
            actual = Extension.ToEnumerable<T>(i);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\jjohnson\\Documents\\GitHub\\XIX\\source\\src", "/")]
        [UrlToTest("http://localhost:56718/")]
        public void ToEnumerableTest() {
            ToEnumerableTestHelper<GenericParameterHelper>();
        }

        /// <summary>
        ///A test for ValueOrDefault
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\jjohnson\\Documents\\GitHub\\XIX\\source\\src", "/")]
        [UrlToTest("http://localhost:56718/")]
        public void ValueOrDefaultTest() {
            XContainer x = null; // TODO: Initialize to an appropriate value
            string name = string.Empty; // TODO: Initialize to an appropriate value
            string expected = string.Empty; // TODO: Initialize to an appropriate value
            string actual;
            actual = Extension.ValueOrDefault(x, name);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for ValueOrDefault
        ///</summary>
        public void ValueOrDefaultTest1Helper<T>() {
            XContainer x = null; // TODO: Initialize to an appropriate value
            string name = string.Empty; // TODO: Initialize to an appropriate value
            T defval = default(T); // TODO: Initialize to an appropriate value
            T expected = default(T); // TODO: Initialize to an appropriate value
            T actual;
            actual = Extension.ValueOrDefault<T>(x, name, defval);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        [TestMethod()]
        [HostType("ASP.NET")]
        [AspNetDevelopmentServerHost("C:\\Users\\jjohnson\\Documents\\GitHub\\XIX\\source\\src", "/")]
        [UrlToTest("http://localhost:56718/")]
        public void ValueOrDefaultTest1() {
            ValueOrDefaultTest1Helper<GenericParameterHelper>();
        }
    }
}
