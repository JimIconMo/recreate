﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using IR.Dependency;

namespace IR.Entities {
    public class CGOverview : ICGOverview {
        public ICGSection CorporateGovernance { get; set; }
        public ICGSection CorporateCitizenship { get; set; }
        public static IEnumerable<ICGOverview> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static ICGOverview From(XElement ele) {
            var ret = new CGOverview() {
                CorporateGovernance = CGSection.From(ele),
                CorporateCitizenship = new CGSection()
                //CorporateGovernance  = CGSection.From(ele.Element("CorporateGovernance")),
                //CorporateCitizenship = CGSection.From(ele.Element("CorporateCitizenship"))
            };
            return ret;
        }

        public class LinkItem : ILinkItem {
            public string Title { get; set; }
            public ILinkNoIcon[] Links { get; set; }
        }

        public class Header : IHeader {
            public string ImageUrl { get; set; }
            public string AltText { get; set; }
            public string Text { get; set; }
        }

        public class CGSection : ICGSection {
            public IHeader Header { get; set; }
            public ILinkItem[] LinkItems { get; set; }
            public static IEnumerable<ICGSection> From<X>(X x) where X : IEnumerable<XElement> {
                return x.Select(ele => From(ele));
            }
            public static ICGSection From(XElement ele) {
                var ret = new CGSection() {
                    Header       = ele.Elements("Header").Select(e => new Header() {
                        ImageUrl = e.Element("Image").ValueOrDefault("Url"),
                        AltText  = e.Element("Image").ValueOrDefault("AltText"),
                        Text     = e.ValueOrDefault("Text")
                    }).Single(),
                    LinkItems    = ele.Element("LinkItems").Elements("LinkItem").Select(e => new LinkItem() {
                        Title    = e.ValueOrDefault("Title"),
                        Links    = e.Elements("Link").Select(a => new LinkNoIcon() {
                            Text = a.ValueOrDefault("Text"),
                            Url  = a.ValueOrDefault("Url")
                        }).ToArray()
                    }).ToArray()
                };
                return ret;
            }
        }
    }
}