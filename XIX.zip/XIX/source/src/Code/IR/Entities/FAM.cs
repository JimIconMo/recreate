﻿using System.Collections.Generic;
using System.Linq;
using System.Xml;
using IR.Dependency;
using System.Xml.Linq;

namespace IR.Entities {
    public class FAM : IFAM {
        internal static IEnumerable<ILinkNoIcon> ExtractLinks(IEnumerable<XNode> nodes) {
            foreach (XNode node in nodes) {
                if (node.NodeType == XmlNodeType.Element) {
                    var ele = ((XElement)node);
                    if (ele.Name == "a")
                        yield return new LinkNoIcon(ele.Attribute("href") != null ? ele.Attribute("href").Value : "", ele.Value);

                    else if (ele.Nodes().Count() > 0)
                        foreach (ILinkNoIcon k in ExtractLinks(ele.Nodes()))
                            yield return k;
                }
            }
        }
        public int Year { get; set; }
        public IImage BannerImage { get; private set; }
        public string Title { get; private set; }
        public string Subtitle { get; private set; }

        public IEnumerable<ILinkNoIcon> HeaderLinks { get; private set; }
        public IEnumerable<IFamSegment> Segments { get; private set; }
        //helper
        public IFAM ForYear(int year) {
            Year = year;
            return this;
        }
        public static IEnumerable<IFAM> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static IFAM From(XElement ele) {
            return new FAM() {
                Title = ele.ValueOrDefault("Title"),
                Subtitle = ele.ValueOrDefault("Subtitle"),
                HeaderLinks = ExtractLinks(ele.Element("Subtitle").Nodes()),
                BannerImage = new ImageEntity(ele.ValueOrDefault("BannerImage/Url"), ele.ValueOrDefault("BannerImage/AltText")),
                Segments = ele.Descendants("Segment").Select(seg => new Event() {
                    Speaker = seg.ValueOrDefault("Speaker/Name"),
                    Title = seg.ValueOrDefault("Speaker/Position"),
                    Dept = seg.ValueOrDefault("Speaker/Department"),
                    ThumbnailUrl = seg.ValueOrDefault("ThumbnailImage/Url"),
                    ThumbnailAltText = seg.ValueOrDefault("ThumbnailImage/AltText"),
                    Links = seg.Element("LinkItems").Elements("Link").Select(l => new Link() {
                        Text = l.ValueOrDefault("Text"),
                        IconUrl = l.ValueOrDefault("Icon"),
                        LinkUrl = l.ValueOrDefault("Url")
                    }).ToArray()
                }).ToArray()
            };
        }
    }
}