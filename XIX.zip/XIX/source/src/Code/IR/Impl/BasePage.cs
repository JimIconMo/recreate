﻿using System;
using System.Web.Configuration;
using System.Web;

namespace IR
{
    public class BasePage : System.Web.UI.Page
    {
        public IR.Shared.Site SiteMaster { get { return (IR.Shared.Site)Master; } }
        public string DataError { get; set; }
        public BasePage() : base() {
            base.InitComplete += new EventHandler((sender, e) => DataBind());
            base.DataBinding  += new EventHandler((sender, e) => SiteMaster.DataController.Print(">>> @BasePage_DataBinding() sender ==> {0}, SiteMaster.DataController ==> '{1}'", SiteMaster.DataController));
            base.LoadComplete += new EventHandler((sender, e) => sender.Print(">>> @BasePage_LoadComplete() sender ==> {0}, SiteMaster.DataController ==> '{1}'", SiteMaster.DataController));
            base.Error        += new EventHandler((sender, e) => sender.Print(">>> @BasePage_Error() sender ==> {0}"));
        }

        public string EscapeUrl(string url = null) { return EscapeUrl("{0}", url); }
        public string EscapeUrl(string fmt, string url) {
            Func<string,string> esc = s => Uri.EscapeUriString(s).Replace("/", Uri.HexEscape('/')).Replace(":", Uri.HexEscape(':'));
            return string.Format(fmt, esc(WebConfigurationManager.AppSettings["AppHost"] + VirtualPathUtility.Combine(HttpRuntime.AppDomainAppVirtualPath, url ?? Request.FilePath))).Print(">>> EscapeUrl('{1}') => {0}", url);
        }
        public string GetAppSetting(string key) { return WebConfigurationManager.AppSettings[key]; }
    }
}