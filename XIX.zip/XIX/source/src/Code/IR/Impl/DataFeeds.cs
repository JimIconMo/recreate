﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Configuration;
using System.Xml.Linq;
using System.Xml.Serialization;
using IR.Dependency;
using IR.Entities;

namespace IR.Impl {
    public class DataFeeds : IDataFeeds {
        string DataHost(Feeds feed) { return DataHost(feed.ToString()); }
        string DataHost(string item = "") {
            return string.Format(
                WebConfigurationManager.AppSettings["DataForm"], 
                WebConfigurationManager.AppSettings["DataHost"], 
                item);
        }

        string MSIRHost(string item = "") {
            return string.Format(
                WebConfigurationManager.AppSettings["MSIRForm"], 
                WebConfigurationManager.AppSettings["MSIRHost"], 
                item);
        }

        public IEnumerable<T> GetCache<T>(string key = null, Func<string,IEnumerable<T>> get = null) {
            key = key ?? typeof(T).Name;
            var obj = HttpContext.Current.Cache[key].Print(">>> Cache['{1}'] ==> {0}", key);
            if (obj == null && get != null) HttpContext.Current.Cache.Add(key,
                obj = get(key), null, System.Web.Caching.Cache.NoAbsoluteExpiration,
                new TimeSpan(1, 0, 0), System.Web.Caching.CacheItemPriority.AboveNormal, null).Print("... Cache['{1}'] +=> {0}", key); ;
            return (IEnumerable<T>)obj;
        }
        public IEnumerable<T> GetCache<T>(Feeds feed, Func<string,IEnumerable<T>> get = null) { return GetCache(DataHost(feed), get); }
        public IEnumerable<T> GetCache<T>(Func<string,IEnumerable<T>> get = null) { return GetCache(null, get); }
        public T GetCache<T>(string key = null, Func<string,T> get = null) {
            key = key ?? typeof(T).Name;
            var obj = HttpContext.Current.Cache[key].Print(">>> Cache['{1}'] ==> {0}", key);
            if (obj == null && get != null) HttpContext.Current.Cache.Add(key,
                obj = get(key), null, System.Web.Caching.Cache.NoAbsoluteExpiration,
                new TimeSpan(1, 0, 0), System.Web.Caching.CacheItemPriority.AboveNormal, null).Print("... Cache['{1}'] +=> {0}", key);
            return (T)obj;
        }
        public T GetCache<T>(Feeds feed, Func<string,T> get = null) { return GetCache(DataHost(feed), get); }
        public T GetCache<T>(Func<string,T> get = null) { return GetCache(null, get); }
        public IEnumerable<T> Get<T>() {
            Func<string,IEnumerable<XElement>> xel = url => {
                try { 
                    return XElement.Load(url).Elements().Print(">>> XElement.Load('{1}').Elements() ==> {0}", url);
                } catch (Exception ex) {
                    ex.Print(">>> XElement.Load('{1}').Elements() ==> XElement.EmptySequence\r\n... Error: {0}", url);
                    return XElement.EmptySequence;
                }
            };
            Func<string> sds = () => {
                string url = "";
                try {
                    return string.Concat(GetCache(Feeds.StaticDataSource, key => new WebClient().DownloadString(url=key).Print(">>> new WebClient().DownloadString('{1}') ==> ", key)));
                } catch (Exception ex) {
                    ex.Print(">>> Error loading content from {1}: {0}", url);
                    return "<error />";
                }
            };
            return new Func<string, IEnumerable<T>>(tname => {
                switch (tname) {
                    case "IEvent":
                        return GetCache(Feeds.Events, key => Event.From(xel(key)).OrderByDescending(d => d.Date)).Cast<T>();
                    case "IEventList":
                        IEnumerable<IEvent> full = GetCache(Feeds.Events, key => Event.From(xel(key)));
                        return GetCache("EventList", key => new EventList() {
                            EventSegments = full.SelectMany(i => i.Segments).Distinct().ToArray().Print(">>> new EventList().EventSegments = full.SelectMany(i => i.Segments).Distinct().ToArray() ==> {0}"),
                            EventTypes = full.Select(i => i.EventType).Distinct().ToArray().Print(">>> new EventList().EventTypes    = full.Select(i => i.EventType).Distinct().ToArray() ==> {0}"),
                            Years = full.Select(i => i.Date.Year).Distinct().ToArray().Print(">>> new EventList().Years         = full.Select(i => i.Date.Year).Distinct().ToArray() ==> {0}"), //TODO: consider using FiscalYear?
                            Speakers = full.Where(i => !string.IsNullOrWhiteSpace(i.Speaker)).Select(i => i.Speaker).Distinct().ToArray().Print(">>> new EventList().Speakers      = full.Where(i => !string.IsNullOrWhiteSpace(i.Speaker)).Select(i => i.Speaker).Distinct().ToArray() ==> {0}")
                        }).ToEnumerable().Cast<T>();
                    case "IFAM":
                        return GetCache(Feeds.FAM, key => Enumerable.Range(2010, DateTime.Now.Year - 2010).SelectMany(y => FAM.From(xel(DataHost(string.Format("FAM{0}", y)))).Select(f=>f.ForYear(y)))).Cast<T>();
                    case "IAnnouncement":
                        return GetCache(Feeds.Announcements, key => Announcement.From(xel(key))).Cast<T>();
                    case "ISQAFeed":
                        return GetCache(Feeds.StockSplit, key => SQAFeed.From(xel(key))).Cast<T>();
                    case "ICGSection":
                        return GetCache(Feeds.CGOverview, key => CGOverview.From(xel(key))).Cast<T>();
                    case "IAnnualReport":
                        return GetCache(Feeds.AnnualReportQuickLink, key => AnnualReport.From(XElement.Load(key).ToEnumerable())).Cast<T>();
                    case "IHomeTiles":
                        return GetCache("IHomeTiles", key => HomeTiles.From(XElement.Parse(sds()).ToEnumerable())).Cast<T>();
                    case "IEarnings<SectionsEnum>":
                        return GetCache("IEarnings<SectionsEnum>", key => EarningsReleases.From(XElement.Parse(sds()).ToEnumerable())).Cast<T>();
                    default:
                        throw new NotImplementedException();
                }
            })(typeof(T).Name.Print(">>> Get<{0}>() ==>")).Print("... {0}");
        }
    }
}