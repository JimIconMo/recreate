﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public interface IFAM
    {
        IFAM ForYear(int year);
        int Year { get; }
        IImage BannerImage { get; }
        string Title { get; }
        string Subtitle { get; }
        IEnumerable<ILinkNoIcon> HeaderLinks { get; }
        IEnumerable<IFamSegment> Segments { get; }
    }
}
