﻿﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Web.UI.WebControls;
using IR.Dependency;

namespace IR.Web {
    public abstract class BaseIRControl<T> : BaseIRSubControl {
        protected IDataFeeds data { get; private set; }
        protected virtual IEnumerable<T> ds { get; set; }
        public BaseIRControl() : base() {
            data = DI.Get<IDataFeeds>();
            ds = data.Get<T>();
        }
    }
}