﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IR.Dependency;

namespace IR.Shared {
    public partial class Stock : IR.Web.BaseIRControl<ISQAFeed> {
        protected new IEnumerable<ISQAQuestionAndAnswer> ds { get; set; }
        protected void Page_Init(object sender, EventArgs e) {
            ds = data.Get<ISQAFeed>().SelectMany(s => s.StockSplitContents).Where(c =>
                c.type == "qa").SelectMany(c =>
                    c.QuestionAndAnswerBody.QuestionAndAnswers);
        }
    }
}