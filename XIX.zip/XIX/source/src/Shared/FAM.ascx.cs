﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IR.Dependency;

namespace IR.Shared {
    public partial class FAM : IR.Web.BaseIRControl<IFAM>{
        private int _year = 0;
        protected int Year { 
            get { return _year; }
            set { _year = value; }
        }
        protected override IEnumerable<IFAM> ds {
            get { return base.ds.Where(f => _year.Equals(f.Year)); }
            set { base.ds = value; }
        }
        public IFAM Data { get { return ds.First(); } }
        protected void Page_Init(object sender, EventArgs e) {
            int _year = int.TryParse(Request["year"] ?? "0", out _year)? _year : DateTime.Today.Year - 1;
        }
        public IEnumerable<string> HeaderLinks(IEnumerable<ILinkNoIcon> links) {
            return links.Select(ea => string.Format("<a href='{0}'>{1}</a>", HttpUtility.HtmlAttributeEncode(ea.Url), HttpUtility.HtmlEncode(ea.Text)));
        }
    }
}