//= require "scout"
//= require "placeholder"

var IR = IR || {};

IR.orientation = (function($) {
	function doChange() {
		/* each controller can define a render method that will get called on orientation change */
		IR.util.controller!="" && (typeof IR[IR.util.controller].render === "function") && IR[IR.util.controller].render();
	}

	function handlerientationChange(evt) {
		if ($.profile.os.toLowerCase()=="android") setTimeout(doChange,400);
		else doChange();
	}

	return handlerientationChange;
})(Scout);

IR.isMenuOpen = false;

IR.common = {
	init: function() {
		window.addEventListener($.profile.orientationEvent, IR.orientation, false);
		IR.orientation();

		function openMenu() {
			$("#container").animate({"margin-left":"-90%"},0.3,{ease:"ease-out"});
			$(".menu-btn").animate({"right":"-40px"},0.3,{ease:"ease-out"}).find(".label").text("back");
			$(".menu-btn .icon").css("background-position","0px -24px");

			IR.isMenuOpen = true;
		}

		function closeMenu() {
			$("#container").animate({"margin-left":"0"},0.3,{ease:"ease-out"});
			$(".menu-btn").animate({"right":"10px"},0.3,{ease:"ease-out"}).find(".label").text("menu");
			$(".menu-btn .icon").css("background-position","0px 0px");

			IR.isMenuOpen = false;
		}

		//global button handlers
		$(".menu-btn").touch("tap",function(evt){
			if (!IR.isMenuOpen) openMenu();
			else closeMenu();
		});

		$("#container").touch("swipe",function(evt){
			if (window.scrollY>105) return;

			switch (evt.touchType) {
				case "swipeLeft":
					if (IR.isMenuOpen) return;
					evt.preventDefault();
					openMenu();
					break;
				case "swipeRight":
					if (!IR.isMenuOpen) return;
					evt.preventDefault();
					closeMenu();
					break;
			}
		});

		$("li.share").touch("tap",function(evt){
			var $li = $(this),
				$tile = $li.find(".tile");

			if ( $.stripPX($tile.css("height"))==30 ) {
				$("ul.container").css("margin-top","-30px");

				if ( $.stripPX($("li.follow").find(".tile").css("height"))==30  )
					$("li.follow").css("margin-top","40px");
				

				$li.css({"height":"70px","margin-top":"0px"});
				$tile.animate({height:"70px"},0.3,{ease:"ease-out",complete:function(){
					$tile.find("ul.btns li").css("display","block");
					$tile.find("ul.btns li").animate({opacity:1});

					$tile.find(".close").css("display","block");
					$tile.find(".close").animate({opacity:1});
				}});
				$tile.find(".label .icon").css({"display":"none","opacity":"0"});
			} else {
				$tile.find("ul.btns li").animate({opacity:0},0.1,{complete:function(){
					$tile.find("ul.btns li").css("display","none");
				}});
				$tile.find(".close").animate({opacity:0},0.1,{complete:function(){
					$tile.find(".close").css("display","none");
					$tile.animate({height:"30px"},0.3,{ease:"ease-out",complete:function(){
							$tile.find(".label .icon").css("display","block").animate({"opacity":"1"},0.3,{ease:"ease-out"});
							$("li.follow").css("margin-top","0px");

							if ( $.stripPX($("li.follow").find(".tile").css("height"))==30  ) {
								$("ul.container").css("margin-top","10px");
								$li.css({"height":"30px","margin-top":"0px"});
							} else {
								$li.css({"height":"30px","margin-top":"40px"});
							}
					}});
				}});
			}
		});

		$("li.follow").touch("tap",function(evt){
			var $li = $(this),
				$tile = $(this).find(".tile");
			
			if ( $.stripPX($tile.css("height"))==30 ) {
				$("ul.container").css("margin-top","-30px");

				if ( $.stripPX($("li.share").find(".tile").css("height"))==30  )
					$("li.share").css("margin-top","40px");

				$li.css({"height":"70px","margin-top":"0px"});
				$tile.animate({height:"70px"},0.3,{ease:"ease-out",complete:function(){
					$tile.find("ul.btns li").css("display","block");
					$tile.find("ul.btns li").animate({opacity:1});

					$tile.find(".close").css("display","block");
					$tile.find(".close").animate({opacity:1});
				}});
				$tile.find(".label .icon").css({"display":"none","opacity":"0"});
			} else {
				$tile.find("ul.btns li").animate({opacity:0},0.1,{complete:function(){
					$tile.find("ul.btns li").css("display","none");
				}});
				$tile.find(".close").animate({opacity:0},0.1,{complete:function(){
					$tile.find(".close").css("display","none");
					$tile.animate({height:"30px"},0.3,{ease:"ease-out",complete:function() {
							$tile.find(".label .icon").css("display","block").animate({"opacity":"1"},0.3,{ease:"ease-out"});
							$("li.share").css("margin-top","0px");

							if ( $.stripPX($("li.share").find(".tile").css("height"))==30  ) {
								$("ul.container").css("margin-top","10px");
								$li.css({"height":"30px","margin-top":"0px"});
							} else {
								$li.css({"height":"30px","margin-top":"40px"});
							}
					}});
				}});
			}
		});

		if ($.profile.os.toLowerCase()!="windows") $.hideURLBar();
	},
	post: function() {
		
	}
};

IR.events = {
	init: function() {
		function closeAll() {
			$(".event-result-hero .container").each(function(index,val,array){
				if ( $(val).attr("data-isopen") == "true" ) {
					$(val).find(".main").animate({"margin-left":"0"},0.3,{ease:"ease-out"});
					$(val).attr("data-isopen","false");
				}
			});

			$(".event-item").each(function(index,val,array){
				if ( $(val).attr("data-isopen") == "true" ) {
					$(val).animate({"margin-left":"0"},0.3,{ease:"ease-out"});
					$(val).attr("data-isopen","false");
				}
			});
		}

		//event results
		$(".event-result-hero .container").attr("data-isopen","false");
		$(".event-result-hero .container").touch("tap",function(evt) {
			evt.preventDefault();
			if ( $(this).attr("data-isopen") == "true" ) {
				$(this).find(".main").animate({"margin-left":"0"},0.3,{ease:"ease-out"});
				$(this).attr("data-isopen","false");
			} else {
				closeAll();
				$(this).find(".main").animate({"margin-left":"-50%"},0.3,{ease:"ease-out"});
				$(this).attr("data-isopen","true");
			}
		});

		$(".event-item").attr("data-isopen","false");
		$(".event-item .main").touch("tap",function(evt){
			evt.preventDefault();
			var $parent = $(this).parent();
			if ( $parent.attr("data-isopen") == "false" ) {
				closeAll();
				$parent.animate({"margin-left":"-100%"},0.3,{ease:"ease-out"});
				$parent.attr("data-isopen","true");
			} 
		});

		$(".event-item .secondary").touch("tap",function(evt){
			var $parent = $(this).parent();
			if ( $parent.attr("data-isopen") == "true" ) {
				$parent.animate({"margin-left":"0"},0.3,{ease:"ease-out"});
				$parent.attr("data-isopen","false");
			}
		});

		//filter
		$(".collapsed").touch("tap",function(evt){
			var $expanded = $(this).parent().find(".expanded");
			if ( $expanded.css("display") == "none" ) {
				$(this).find(".icon").css("-"+$.profile.vendor+"-transform","rotate(-180deg)");
				$expanded.css("display","block");

				$("body").touch("tap",function(evt){
					if ($("#filter")[0].contains(evt.target)) return;

					$expanded.css("display","none");
					$("body").removeTouch();
				});
			}
			else {
				$(this).find(".icon").css("-"+$.profile.vendor+"-transform","rotate(0deg)");
				$expanded.css("display","none");
				$("body").removeTouch();
			}
		});

		$(".reset").touch("tap",function(evt){
			var t = $(".expanded input").prop("value");
			$(".expanded input").prop("value","");
			$(".expanded select").prop("selectedIndex",0);
		});

		//this is the filter submit button
		$(".go").touch("tap",function(evt){
			$(this).parent().parent()[0].submit();
		});

		//more button at bottom of page
		$(".more-btn").touch("tap",function(evt){
			$.log("load more articles");
			window.location.href = window.location.href+"#";
		});
	},
	render: function() {

	}
};

IR.earnings = {
	init: function() {
		$(".current-section").touch("tap",function(evt){
			var $container = $(this).parent();
			if ($container.hasClass("closed")) {
				$(this).siblings().css("display","block");
				$container.removeClass("closed").addClass("open");
				$(this).find(".arrow-icon").css("-"+$.profile.vendor+"-transform","rotate(-180deg)");
			} else {
				$(this).siblings().css("display","none");
				$container.removeClass("open").addClass("closed");
				$(this).find(".arrow-icon").css("-"+$.profile.vendor+"-transform","rotate(0deg)");
			}
		});
	},
	segments: function() {
		$('nav[role="segments"] li').touch("tap",function(evt){
			$('nav[role="segments"] li').removeClass("selected");
			$(this).addClass("selected");

			$('article').removeClass("selected");
			$('article[id="'+ $(this).attr("id") +'"]').addClass("selected");
		});
	}
};

IR.util = {
	controller: "",
	action: "",
	exec: function( controller, action ) {
		/* will check for and then run controllers and actions */
		var ns = IR,
			action = ( typeof action === "undefined" || action === "" ) ? "init" : action;
			
			if ( controller !== "" && ns[controller] && typeof ns[controller][action] === "function" ) {
				ns[controller][action]();
			}
	},

	init: function() {
		/* grab the controller or action settings as deinfed on each page */
		var body = document.body;
		IR.util.controller = body.attributes['data-controller'].value;
		IR.util.action = body.attributes['data-action'].value;

		/* the common controller runs for every page */
		this.exec( "common" );

		/* use the defined valuse to run the applicable controllers and actions per page load */
		if (IR.util.controller!='') {
			this.exec( IR.util.controller );
			if (IR.util.action!='') this.exec( IR.util.controller, IR.util.action );
		}
		this.exec( "common", "post" );
  	}
};

$(document).ready(function pageReady() {
	IR.util.init();
});