//requirs scout and page to be loaded first
(function() {
	var el = document.createElement("input");
	if (typeof el.placeholder === "undefined" && typeof Object.defineProperty !=="undefined") {
		$("input").each(function placeholder(index,val,array){
			var t = $(val).attr("type"),
				p = $(val).attr("placeholder");
			
			if (t=="text" || t=="email") {
				Object.defineProperty(val, 'placeholder', {
				    get: function() {
				        return this.value;
				    },
				    set: function(v) {
				        this.value = v;
				    }
				});
				
				val.addEventListener("focus",function(evt){
					if (this.value==p) this.value = '';
				},true);
				val.addEventListener("blur",function(evt){
					if (this.value=="") this.value = p;
				},true);
				val.placeholder = p;
			}
		});
	}
})();