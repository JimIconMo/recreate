﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IR.Shared.Controls {
    public partial class MenuControl : IR.Web.BaseIRSubControl {
        public string Role { get; set; }
        protected void Page_Load(object sender, EventArgs e) {
            this.ClientIDMode = System.Web.UI.ClientIDMode.Predictable;
        }
    }
}