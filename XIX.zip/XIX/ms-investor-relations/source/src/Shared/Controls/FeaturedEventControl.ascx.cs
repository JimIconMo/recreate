﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IR.Dependency;

namespace IR.Shared.Controls {
    public partial class FeaturedEventControl : IR.Web.BaseIRSubControl {
        public IEvent Data { get; set; }
        public int ReminderViewIndex {
            get {
                return DateTime.UtcNow.CompareTo(Data.Date) == -1 || Data.Links.Count(a =>
                    a.Text.StartsWith("Transcript", StringComparison.OrdinalIgnoreCase)
                    ) == 0 ? 0 : 1;
            }
        }
        public IEnumerable<ILink> TranscriptLinks {
            get { return Data.Links.Where(a => a.Text.StartsWith("Transcript", StringComparison.OrdinalIgnoreCase)); }
        }
        protected void Page_Load(object sender, EventArgs e) {

        }
    }
}