﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IR.Dependency;

namespace IR.Shared {
    public partial class Announcements : IR.Web.BaseIRControl<IAnnouncement> {
        public bool ShowHeader { get; set; }
        //public string Title { get { return Header1; } }
        //public DateTime Date { get { return DateTime.UTC; } }
        //public string LinkUrl { get { return Links.DefaultIfEmpty(new IR.Entities.AnnouncementLink() { URL = "" }).FirstOrDefault().URL; } }
        protected void Page_Load(object sender, EventArgs e) {
        }
    }
}