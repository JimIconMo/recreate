﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;

namespace IR.Shared {
    public partial class Site : System.Web.UI.MasterPage {
        protected void Page_Init(object sender, EventArgs e) {
            CssClass = DataController = "events";
        }
        public string CssClass { get; set; }
        public string DataAction { get; set; }
        public string DataController { get; set; }
        private string _title_pre = "Microsoft Investor Relations";
        private string _title_sep = " - ";

        /// <summary> Content pages can still just set Page.Title normally. </summary>
        public string TitlePrefix {
            get { return this._title_pre; }
            set { this._title_pre = value ?? ""; }
        }
        protected string Title {
            get { return this.head.Title.StartsWith(_title_pre + _title_sep) ? 
                    this.head.Title.Substring(_title_pre.Length + _title_sep.Length) : this.head.Title; 
            }
            set { this.head.Title = (value ?? "").StartsWith(_title_pre + _title_sep) ? "" : 
                    _title_pre + _title_sep + value; }
        }
    }
}