﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IR.Dependency;

namespace IR.Shared {
    public partial class FAM : IR.Web.BaseIRControl<IFAM>{
        private int _year;
        protected int Year { 
            get { return _year; }
            set { _year = value; }
        }
        protected IEnumerable<IEvent> segmentsDataSource {
            get { return ds.SelectMany(r => r.Segments.Where(s => _year.Equals(s.FiscalYear))); }
        }
        protected void Page_Init(object sender, EventArgs e) {
            int _year = int.TryParse(Request["year"] ?? "0", out _year)? _year : DateTime.Today.Year - 1;
        }
    }
}