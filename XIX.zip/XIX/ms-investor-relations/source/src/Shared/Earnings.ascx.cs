﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using IR.Dependency;

namespace IR.Shared {
    public partial class Earnings : IR.Web.BaseIRControl<IEarnings<SectionsEnum>> {
        public IDictionary<SectionsEnum, ISection> SectDict { get { return ds.Single().Sections; } }
        public IDictionary<SectionsEnum, ISection> SectLink { get { return ds.Single().Sections; } }

        protected SectionsEnum sect;
        protected int idx_sect, idx_segm;
        //ISection SectionIndex { get { return SectDict[(SectionsEnum)idx_sect]; } }
        //int SegmentIndex { get { SectDict.Keys.Select((k) => new List<SectionsEnum>()).Index(idx_segm); } }
        string ContentHtml { get; set; }
        //protected void Page_Load(object sender, EventArgs e) {
        //    //SectionEnum _i_ = SectionsEnum.Parse(typeof(SectionsEnum), HttpContext.Current.Request["section"];

        //    using (var wc = new WebClient()) {
        //        string url = "squeek";
        //        var html = wc.DownloadString(url);
        //        ContentHtml = data.GetCache<string>(url, key => wc.DownloadString(key));
        //    }

        //}
    }
}