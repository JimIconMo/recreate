﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using IR.Dependency;
using IR.Entities;

namespace IR.Shared {
    public partial class Events : IR.Web.BaseIRControl<IEvent> {
        private IEnumerable<IEventList> elist;
        public string speaker, type, segment;
        public int year, month;
        public int count;
        public IEnumerable<string> EventTypes { get { return new string[] { "All" }.Concat(elist.Single().EventTypes); } }
        public IEnumerable<string> EventSegments { get { return new string[] { "All" }.Concat(elist.Single().EventSegments); } }
        public IEnumerable<string> Speakers { get { return new string[] { "All" }.Concat(elist.Single().Speakers); } }
        public IEnumerable<int> Years { get { return elist.Single().Years; } }
        public IEnumerable<string> Months { get { return new string[] { "All", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }; } }
        public IEnumerable<IEvent> Featured { get { return ds.Where(evt => evt.Featured); } }
        public IEnumerable<IEvent> NotFeatured { get { return ds.Where(evt => !evt.Featured); } }

        protected override void OnInit(EventArgs e) {
            base.OnInit(e);
            elist   = data.Get<IEventList>();
            speaker = Request["speaker"] ?? "";
            type    = Request["type"] ?? "";
            segment = (Request["segment"] ?? "");
            year    = int.TryParse(Request["year"] ?? "", out year)? year : 0;
            month   = int.TryParse(Request["month"] ?? "", out month)? month : 0;
            try {
                ds = data.Get<IEvent>().Where(evt =>
                           (speaker == "" || evt.Speaker.IndexOf(speaker, StringComparison.InvariantCultureIgnoreCase) != -1)
                        && (type    == "" || evt.EventType  == type)
                        && (segment == "" || (evt.Segments  != null && evt.Segments.Contains(segment)))
                        && (year    == 0  || evt.Date.Year  == year 
                                          || evt.FiscalYear == year)
                        && (month   == 0  || evt.Date.Month == month)
                    );
                count = ds.Count();
            } catch (Exception ex) {
                PageBase.DataError = ex.Print(">>> Error initializing events control for aggregate data: {0}").Message;
                elist = new IR.Entities.EventList();
            }
        }
    }
}