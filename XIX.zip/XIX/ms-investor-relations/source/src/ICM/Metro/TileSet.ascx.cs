﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ICM.Metro {
    [ParseChildren(true)]
    public partial class MetroTileSet : UserControl {
        [PersistenceMode(PersistenceMode.InnerProperty), TemplateContainer(typeof(TemplateItem))]
        public List<MetroTile> Tiles { get; set; }

        public MetroTileSet() {
            Tiles = new List<MetroTile>();
        }

        protected override void CreateChildControls() {
            TemplateItem container = new TemplateItem("");
            Control placeholder = (PlaceHolder)this.FindControl("TilesCollectionPlaceholder");
            foreach (var tile in Tiles) {
                placeholder.Controls.Add(tile);
            }
            placeholder.DataBind();
        }
    }
    public class TemplateItem : Control, INamingContainer {
        private String _message = null;

        public TemplateItem(String message) {
            _message = message;
        }

        public String Message {
            get { return _message; }
            set { _message = value; }
        }
    }
}