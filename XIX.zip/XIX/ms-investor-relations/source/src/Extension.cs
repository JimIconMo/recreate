﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using IR.Dependency;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Web.Script.Serialization;
using System.Diagnostics;

namespace IR
{
    public static class Extension
    {
        [DebuggerStepThrough]
        public static IEnumerable<Exception> RecurseInner(this Exception exception) {
            while ((exception = exception.InnerException) != null) 
                yield return exception;
        }

        [DebuggerStepThrough]
        public static T Print<T>(this T t, string fmt, params object[] obj) {
            try { Debug.WriteLine(fmt ?? ">>> {0}", new object[] { t }.Concat(obj).ToArray()); } catch {}
            return t;
        }
        [DebuggerStepThrough]
        public static T Print<T>(this T t, string fmt = null) {
            try { Debug.WriteLine(fmt ?? ">>> {0}", t); } catch {}
            return t;
        }
        [DebuggerStepThrough]
        public static Exception Print(this Exception ex, string fmt = null, string msg = null) {
            var lvl = Debug.IndentLevel;
            try {
                Debug.WriteLine(fmt ?? ">>> {0}: {1}.", msg ?? "ERROR", ex.Message);
                Debug.WriteLine(">>> Stack Trace: {0}", ex.StackTrace);
                foreach (Exception x in ex.RecurseInner()) {
                    Debug.Indent(); 
                    Debug.WriteLine(ex.Message);
                }
            } catch {}
            Debug.IndentLevel = lvl;
            return ex;
        }

        [DebuggerStepThrough]
        public static string ValueOrDefault(this XContainer x, string name) {
            return x.ValueOrDefault<string>(name, "");
        }

        private static readonly Dictionary<Func<string, dynamic>, Type> _tdict_ValueOrDefault = 
            new Dictionary<Func<string, dynamic>, Type>() {
                {s=>s??"",                  typeof(string)},
                {s=>bool.Parse(s),          typeof(bool)}, 
                {s=>char.Parse(s),          typeof(char)}, 
                {s=>sbyte.Parse(s),         typeof(sbyte)}, 
                {s=>byte.Parse(s),          typeof(byte)}, 
                {s=>Int16.Parse(s),         typeof(Int16)},
                {s=>UInt16.Parse(s),        typeof(UInt16)},
                {s=>Int32.Parse(s),         typeof(Int32)}, 
                {s=>UInt32.Parse(s),        typeof(UInt32)}, 
                {s=>Int64.Parse(s),         typeof(Int64)},
                {s=>UInt64.Parse(s),        typeof(UInt64)},
                {s=>Guid.Parse(s),          typeof(Guid)}, 
                {s=>DateTime.Parse(s),      typeof(DateTime)}, 
                {s=>XDocument.Parse(s),     typeof(XDocument)}, 
                {s=>XElement.Parse(s),      typeof(XElement)}, 
                {s=>new UriBuilder(s).Uri,  typeof(Uri)}
            };
        [DebuggerStepThrough]
        public static T ValueOrDefault<T>(this XContainer x, string name, T defval = default(T)) {
            var tdict = _tdict_ValueOrDefault.Where(t => t.Value.Equals(typeof(T)));
            Func<string, dynamic> parse = str => {
                if (str != null)
                    foreach (var p in tdict.Select(td => (T)td.Key(str)))
                        return p;
                return defval;
            };
            Func<XAttribute, T> nil = v =>
                v == null ? defval : parse(v.Value) ?? defval;

            if (x == null || !(x is XElement) || string.IsNullOrWhiteSpace(name))
                return defval;

            string[] sp = name.Split(new char[] { '/' }, 2);
            if (sp[0].StartsWith("@"))
                return nil(((XElement)x).Attribute(sp[0].Substring(1)));
            if ((x = x.Element(sp[0])) == null) 
                return defval;
            if (sp.Length == 1)
                return parse(((XElement)x).Value) ?? defval;
            return x.ValueOrDefault<T>(sp[1]);
        }

        [DebuggerStepThrough]
        public static IEnumerable<T> ToEnumerable<T>(this T i) {
            yield return i;
        }
    }
}