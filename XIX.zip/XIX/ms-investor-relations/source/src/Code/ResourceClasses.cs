using System;
using System.Reflection;
using System.Resources;

namespace ICM.Dependency
{
	public class ResourceClasses
	{
        
		public static Type GetResourceType(String context)
		{
			String typeName = "Resources." + context;
			Type t = null;
			t = Assembly.GetExecutingAssembly().GetType(typeName);
			if (t != null) return t;
			
			switch (context)
			{
                default: throw new Exception("Resource type " + context + " is not defined");
			}
		}
	}
}
