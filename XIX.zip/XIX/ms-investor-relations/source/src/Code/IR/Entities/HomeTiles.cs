﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using IR.Dependency;

namespace IR.Entities {
    public class HomeTiles : IHomeTiles {
        public string ERHeader { get; set; }
        public string EarningsEventID { get; set; }
        public string AnnualMeetingID { get; set; }
        public string PRHtml { get; set; }
        public string PRDocx { get; set; }
        public string FinancialStatementXlsx { get; set; }
        public string PerformanceContentXml { get; set; }
        public string ICXml { get; set; }
        public string KPIXlsx { get; set; }
        public string CommitteesHtm { get; set; }
        public string FactSheetHtm { get; set; }
        public IEarnings[] Earnings { get; set; }
        public ISegmentName[] SegmentNames { get; set; }
        public ICorp Corporate { get; set; }
        public string EarningsHeadline { get { return ERHeader; } }

        public static IEnumerable<IHomeTiles> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static IHomeTiles From(XElement ele) {
            var ret = new HomeTiles() {
                ERHeader               = ele.ValueOrDefault("CurrentERHeader"),
                EarningsEventID        = ele.ValueOrDefault("CurrentEarningsEventID"),
                AnnualMeetingID        = ele.ValueOrDefault("CurrentAnnualMeetingID"),
                PRHtml                 = ele.ValueOrDefault("CurrentPRHtml"),
                PRDocx                 = ele.ValueOrDefault("CurrentPRDocx"),
                FinancialStatementXlsx = ele.ValueOrDefault("CurrentFinancialStatementXlsx"),
                PerformanceContentXml  = ele.ValueOrDefault("CurrentPerformanceContentXml"),
                ICXml                  = ele.ValueOrDefault("CurrentICXml"),
                KPIXlsx                = ele.ValueOrDefault("CurrentKPIXlsx"),
                CommitteesHtm          = ele.ValueOrDefault("CurrentCommitteesHtm"),
                FactSheetHtm           = ele.ValueOrDefault("CurrentFactSheetHtm"),
                Earnings               = ele.Element("EarningsSections").Elements("EarningsSection").Select(e => new Earnings() {
                    ItemId             = ele.ValueOrDefault("ItemId"),
                    SectionName        = ele.ValueOrDefault("Name")
                }).ToArray(),
                SegmentNames           = ele.Element("SegmentNames").Elements("SegmentName").Select(e => new SegmentName() {
                    Order              = ele.ValueOrDefault("Order"),
                    Name               = ele.ValueOrDefault("Name"),
                    PerformanceTag     = ele.ValueOrDefault("PerformanceTag"),
                    ICTag              = ele.ValueOrDefault("ICTag")
                }).ToArray(),
                Corporate              = ele.Elements("Corporate").Select(e => new Corp() {
                    Name               = ele.ValueOrDefault("Name"),
                    PerformanceTag     = ele.ValueOrDefault("PerformanceTag"),
                    ICTag              = ele.ValueOrDefault("ICTag")
                }).Single()
            };
            return ret;
        }
    }

    public class Earnings : IEarnings {
        public Earnings() { }
        public string ItemId { get; set; }
        public string SectionName { get; set; }
    }

    public class SegmentName : ISegmentName {
        public SegmentName() { }
        public string Order { get; set; }
        public string Name { get; set; }
        public string PerformanceTag { get; set; }
        public string ICTag { get; set; }
    }

    public class Corp : ICorp {
        public Corp() { }
        public string Name { get; set; }
        public string PerformanceTag { get; set; }
        public string ICTag { get; set; }
    }
}