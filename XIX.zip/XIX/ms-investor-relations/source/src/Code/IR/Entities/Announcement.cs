﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using IR.Dependency;

namespace IR.Entities
{
    public class Announcement : IAnnouncement
    {
        public string EntryID { get; set; }
        public bool Active { get; set; }
        public bool ActiveSpecified { get; set; }
        public DateTime CreateTime { get; set; }
        public bool CreateTimeSpecified { get; set; }
        public string ExpirationTime { get; set; }
        public string DisplayOrder { get; set; }
        public string Header1 { get; set; }
        public string Header2 { get; set; }
        public string Header3 { get; set; }
        public bool CheckToEdit { get; set; }
        public bool CheckToEditSpecified { get; set; }
        public IAnnouncementDateTime DateTime { get; set; }
        public IAnnouncementLink[] Links { get; set; }
        public static IEnumerable<IAnnouncement> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static IAnnouncement From(XElement ele)
        {
            return new Announcement()
            {
                EntryID              = ele.ValueOrDefault("EntityID"),
                Active               = ele.ValueOrDefault<bool>("Active"),
                ActiveSpecified      = ele.ValueOrDefault<bool>("ActiveSpecified"),
                CreateTime           = ele.ValueOrDefault<System.DateTime>("CreateTime"),
                CreateTimeSpecified  = ele.ValueOrDefault<bool>("CreateTimeSpecified"),
                ExpirationTime       = ele.ValueOrDefault("ExpirationTime"),
                DisplayOrder         = ele.ValueOrDefault("DisplayOrder"),
                Header1              = ele.ValueOrDefault("Header1"),
                Header2              = ele.ValueOrDefault("Header2"),
                Header3              = ele.ValueOrDefault("Header3"),
                CheckToEdit          = ele.ValueOrDefault<bool>("CheckToEdit"),
                DateTime             = new AnnouncementDateTime()
                {
                    UTC              = ele.ValueOrDefault<System.DateTime>("DateTime/UTC"),
                    UTCSpecified     = ele.ValueOrDefault<bool>("DateTime/UTCSpecified"),
                    Local            = ele.ValueOrDefault<System.DateTime>("DateTime/Local"),
                    LocalSpecified   = ele.ValueOrDefault<bool>("DateTime/LocalSpecified"),
                    TimeZone         = ele.ValueOrDefault("DateTime/TimeZone")
                },
                Links                = ele.Elements("Links").Select(e =>
                    new AnnouncementLink()
                    {
                        Text         = e.ValueOrDefault("Text"),
                        Icon         = e.ValueOrDefault("Icon"),
                        URL          = e.ValueOrDefault("URL/Value"),
                        OpenMode     = e.ValueOrDefault("URL/OpenMode")
                    }).ToArray(),
                CheckToEditSpecified = ele.ValueOrDefault<bool>("CheckToEditSpecified"),
            };
        }
    }
    public class AnnouncementDateTime : IAnnouncementDateTime
    {
        public DateTime UTC { get; set; }
        public bool UTCSpecified { get; set; }
        public DateTime Local { get; set; }
        public bool LocalSpecified { get; set; }
        public string TimeZone { get; set; }
    }
    public class AnnouncementLink : IAnnouncementLink
    {
        public string Text { get; set; }
        public string Icon { get; set; }
        public string URL { get; set; }
        public string OpenMode { get; set; }
    }
}