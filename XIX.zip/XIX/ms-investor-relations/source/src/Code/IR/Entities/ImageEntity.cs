﻿using IR.Dependency;

namespace IR.Entities
{
    public class ImageEntity : IImage
    {
        public ImageEntity(string url, string altText)
        {
            ImageUrl = url;
            AltText = altText;
        }
        public string ImageUrl { get; private set; }
        public string AltText { get; private set; }
    }
}