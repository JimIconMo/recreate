﻿using System.Collections.Generic;
using System.Linq;
using System.Xml;
using IR.Dependency;

namespace IR.Entities
{
    public class FAM : IFAM
    {
        public FAM()
        {
        }
        internal static IEnumerable<ILinkNoIcon> ExtractLinks(IEnumerable<XmlNode> nodes)
        {
            foreach (XmlNode node in nodes)
            {
                if (node.Name == "a")
                    yield return new LinkNoIcon(node.Attributes["href"].InnerText, node.InnerText);
                
                else if (node.ChildNodes != null && node.ChildNodes.Count > 0)
                    foreach(ILinkNoIcon k in ExtractLinks(node.ChildNodes.OfType<XmlNode>()))
                        yield return k;
            }
        }

        //public static IFAM GetFromDeserializedObject(global::IRAnalystMeeting obj)
        //{
        //    var fam = new FAM()
        //    {
        //        Title = obj.Title,
        //        Segments = obj.Segments.Select(seg =>
        //            new Event(){Speaker=seg.Speaker.Name, Title=seg.Speaker.Position, ThumbnailUrl=seg.ThumbnailImage.Url, ThumbnailAltText=seg.ThumbnailImage.AltText,
        //                Links=seg.LinkItems.Select(l => new Link(l.Text, l.Icon, l.Url)).ToArray()}
        //        ),
        //        BannerImage = new ImageEntity(obj.BannerImage.Url, obj.BannerImage.AltText),
        //    };
        //    if (obj.SubTitle is System.Xml.XmlNode[])
        //    {
        //        fam.HeaderLinks = ExtractLinks(obj.SubTitle as XmlNode[]);
        //        fam.Subtitle = ""; //obj.SubTitle.ToString();
        //    }
        //    return fam;
        //}

        public IImage BannerImage { get; private set; }
        public string Title { get; private set; }
        public string Subtitle { get; private set; }

        public IEnumerable<ILinkNoIcon> HeaderLinks { get; private set; }

        public IEnumerable<IEvent> Segments { get; private set; }
    }
}