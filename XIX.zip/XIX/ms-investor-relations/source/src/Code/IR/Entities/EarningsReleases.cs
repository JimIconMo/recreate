﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using IR.Dependency;

namespace IR.Entities {
    public class EarningsReleases : IEarnings<SectionsEnum> {

        public IDictionary<SectionsEnum, ISection> Sections { get; set; }

        public static IEnumerable<IEarnings<SectionsEnum>> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static IEarnings<SectionsEnum> From(XElement ele) {
            var ht = HomeTiles.From(ele);
            var sections = new ISection[] {
                new EarningsSection()
                {
                    Name = "Press Release & Webcast", 
                    Key = SectionsEnum.press, 
                    ContentUrl = ht.PRHtml,
                    Links = new[] {
                        new Link() { Text="docx", IconUrl="", LinkUrl=ht.PRDocx }
                    }
                },
                new EarningsSection()
                {
                    Name = "Financial Statements",
                    Key = SectionsEnum.statements,
                    Links = new[] {
                        new Link() { Text="financial statements", IconUrl="xls.jpg", LinkUrl=ht.FinancialStatementXlsx }
                    }
                },
                new PerformanceSection()
                {
                    Name = "Performance", 
                    Key = SectionsEnum.performance,
                    ContentUrl=ht.PerformanceContentXml
                },
                //new EarningsSection("KPI", SectionsEnum.kpi)
                //{
                    //ContentUrl = obj.CurrentKPIContentXml,
                    //Links = new ILink[] {
                        //new Link("kpi", "xls", obj.KPIXlsx)
                    //}
                //},
                new SegmentResultsSection() 
                {
                    Name = "Segment Results", 
                    Key = SectionsEnum.segment,
                    Links = ht.SegmentNames.Select(seg => new Link() { Text=seg.Name }).ToArray()
                },
            };
            //obj.EarningsSections.Split(',').Select(seg => new EarningsSection(seg)).ToArray()
            return new EarningsReleases() { Sections = sections.ToDictionary<ISection, SectionsEnum>(i => i.Key) };
        }

        /*
        public static EarningsReleases GetFromDeserializedObject(global::Basic obj)
        {
            var sections = new ISection[] {
                new EarningsSection("Press Release & Webcast", SectionsEnum.press)
                {
                    ContentUrl = obj.PressReleaseHtml,
                    Links = new[] {
                        new Link("docx", "", obj.PressReleaseHtml)
                    }
                },
                new EarningsSection("Financial Statements", SectionsEnum.statements)
                {
                     Links = new ILink[] {
                        new Link("financial statements", "xls.jpg", obj.FinancialStatementXlsx)
                     }
                },
                new PerformanceSection("Performance", SectionsEnum.performance)
                {
                     ContentUrl=obj.PerformanceContentXml
                },
                new EarningsSection("KPI", SectionsEnum.kpi)
                {
                    ContentUrl = obj.KPIContentXml,
                    Links = new ILink[] {
                        new Link("kpi", "xls", obj.KPIXlsx)
                    }
                },
                new SegmentResultsSection(obj.SegmentNames.Split(','), "Segment Results", SectionsEnum.segment)
                {
                },
            };
            //obj.EarningsSections.Split(',').Select(seg => new EarningsSection(seg)).ToArray()
            return new EarningsReleases(sections.ToDictionary<ISection, SectionsEnum>(i => i.Key));
        }
        */
    }
}