﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using IR.Dependency;
using IR.Dependency.AnnualReports;

namespace IR.Entities
{
    public class AnnualReport : IAnnualReport
    {
        public string Title { get; set; }
        public string ThumbnailImage_AltText { get; set; }
        public string ThumbnailImage_Url { get; set; }
        public string ThumbnailImageForMobile_AltText { get; set; }
        public string ThumbnailImageForMobile_Url { get; set; }
        public string EnlargedImage_AltText { get; set; }
        public string EnlargedImage_Url { get; set; }
        public string EnlargedImageForMobile_AltText { get; set; }
        public string EnlargedImageForMobile_Url { get; set; }
        public string HttpLink_Target { get; set; }
        public string HttpLink_AltText { get; set; }
        public string HttpLink_Url { get; set; }
        public string DownloadLink_Target { get; set; }
        public string DownloadLink_AltText { get; set; }
        public string DownloadLink_Url { get; set; }
        public string MoreImages { get; set; }
        public bool BeforeAnnualReport { get; set; }
        public Dictionary<ImageTypes, IImage> Images {
            get { return new Dictionary<ImageTypes, IImage>() {
                    { ImageTypes.ThumbnailMobile, new ImageEntity(this.ThumbnailImageForMobile_Url, this.ThumbnailImageForMobile_AltText) },
                    { ImageTypes.ThumbnailDesktop, new ImageEntity(this.ThumbnailImage_Url, this.ThumbnailImage_AltText) },
                    { ImageTypes.FullMobile, new ImageEntity(this.EnlargedImageForMobile_Url, this.EnlargedImageForMobile_AltText) },
                    { ImageTypes.FullDesktop, new ImageEntity(this.EnlargedImage_Url, this.EnlargedImage_AltText) },
                };
            }
        }

        public Dictionary<LinkTypes, ILinkNoIcon> Links {
            get { return new Dictionary<LinkTypes, ILinkNoIcon>() {
                    { LinkTypes.Download, new LinkNoIcon(this.DownloadLink_Url, this.DownloadLink_AltText) },
                    { LinkTypes.FullDesktop, new LinkNoIcon(this.HttpLink_Url, this.HttpLink_AltText) },
                };
            }
        }

        public static IEnumerable<IAnnualReport> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static IAnnualReport From(XElement ele) {
            return new AnnualReport() {
                Title                           = ele.ValueOrDefault("Title"),
                ThumbnailImage_AltText          = ele.ValueOrDefault("ThumbnailImage/AltText"),
                ThumbnailImage_Url              = ele.ValueOrDefault("ThumbnailImage/Url"),
                ThumbnailImageForMobile_AltText = ele.ValueOrDefault("ThumbnailImageForMobile/AltText"),
                ThumbnailImageForMobile_Url     = ele.ValueOrDefault("ThumbnailImageForMobile/Url"),
                EnlargedImage_AltText           = ele.ValueOrDefault("EnlargedImage/AltText"),
                EnlargedImage_Url               = ele.ValueOrDefault("EnlargedImage/Url"),
                EnlargedImageForMobile_AltText  = ele.ValueOrDefault("EnlargedImageForMobile/AltText"),
                EnlargedImageForMobile_Url      = ele.ValueOrDefault("EnlargedImageForMobile/Url"),
                HttpLink_Target                 = ele.ValueOrDefault("HttpLink/@target"),
                HttpLink_AltText                = ele.ValueOrDefault("HttpLink/LinkText"),
                HttpLink_Url                    = ele.ValueOrDefault("HttpLink/Url"),
                DownloadLink_Target             = ele.ValueOrDefault("DownloadLink/@target"),
                DownloadLink_AltText            = ele.ValueOrDefault("DownloadLink/LinkText"),
                DownloadLink_Url                = ele.ValueOrDefault("DownloadLink/Url"),
                MoreImages                      = ele.ValueOrDefault("MoreImages"),
                BeforeAnnualReport              = ele.ValueOrDefault<bool>("MoreImages/@beforeAnnualReport")
            };
        }
    }
}