﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using IR.Dependency;

namespace IR.Entities {
    public class SQAFeed : ISQAFeed {
        public string StockSplitTitle { get; set; }
        public ISQAContent[] StockSplitContents { get; set; }
        public static XElement XAT(XElement x) {
            var ret = new XElement(x.Name.LocalName, x.Nodes().Select(
                d => d.NodeType == System.Xml.XmlNodeType.Element ?
                    ((XNode)XAT((XElement)d)) : d.NodeType == System.Xml.XmlNodeType.Text ?
                    ((XNode)new XText(d.ToString().Trim())) : d)
                );
            foreach (var a in x.Attributes().Where(b => b.Name.LocalName != "xmlns" && (b.Name.NamespaceName == "" || b.Name.NamespaceName == "http://www.w3.org/1999/xhtml/"))) {
                ret.SetAttributeValue(a.Name, a.Value);
            }
            return ret;
        }
        public static IEnumerable<ISQAFeed> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static ISQAFeed From(XElement ele) {
            var rx = new Regex(@"\s\s+");
            Func<XElement, string> trimwsp = x => x == null ? " " : rx.Replace(x.ToString(), " ");
            Func<XElement, string> str = x => x == null ? "" : trimwsp(XAT(x));

            return new SQAFeed() {
                StockSplitTitle = ele.ValueOrDefault("StockSplitTitle"),
                StockSplitContents = ele.Descendants("Content").Select(c =>
                    new SQAContent() {
                        ContentTitle = str(c.Element("ContentTitle")),
                        HtmlBody = str(c.Element("HtmlBody")),
                        ListItemBody = c.Elements("ListItemBody").Select(b =>
                            new SQAListItemBody() {
                                Icon = b.ValueOrDefault("Icon"),
                                ListItems = b.Descendants("ListItem").Select(a =>
                                    new SQAListItem() {
                                        Text = a.ValueOrDefault("Text"),
                                        Target = a.ValueOrDefault("Target"),
                                        Url = a.ValueOrDefault("Url")
                                    }
                                ).ToArray()
                            }
                        ).SingleOrDefault(),
                        HtmlAndListItemBody = c.Elements("HtmlAndListItemBody").Select(b =>
                            new SQAHtmlAndListItemBody() {
                                Icon = b.ValueOrDefault("Icon"),
                                HtmlContent = str(b.Element("HtmlContent")),
                                ListItems = b.Descendants("ListItem").Select(a =>
                                    new SQAListItem() {
                                        Text = a.ValueOrDefault("Text"),
                                        Target = a.ValueOrDefault("Target"),
                                        Url = a.ValueOrDefault("Url")
                                    }
                                ).ToArray()
                            }
                        ).SingleOrDefault(),
                        QuestionAndAnswerBody = c.Elements("QuestionAndAnswerBody").Select(b =>
                            new SQAQuestionAndAnswerBody() {
                                Icon = b.ValueOrDefault("Icon"),
                                QuestionAndAnswers = b.Descendants("QuestionAndAnswer").Select(a =>
                                    new SQAQuestionAndAnswer() {
                                        Question = a.ValueOrDefault("Question"),
                                        Answer = str(a.Element("Answer"))
                                    }
                                ).ToArray()
                            }
                        ).SingleOrDefault(),
                        type = c.Attribute("type") == null ? "" : c.Attribute("type").Value
                    }
                ).ToArray()
            };
        }
    }

    public class SQAContent : ISQAContent {
        public string ContentTitle { get; set; }
        public string HtmlBody { get; set; }
        public ISQAListItemBody ListItemBody { get; set; }
        public ISQAHtmlAndListItemBody HtmlAndListItemBody { get; set; }
        public ISQAQuestionAndAnswerBody QuestionAndAnswerBody { get; set; }
        public string type { get; set; }
    }

    public class SQAListItemBody : ISQAListItemBody {
        public string Icon { get; set; }
        public ISQAListItem[] ListItems { get; set; }
    }
    public class SQAHtmlAndListItemBody : ISQAHtmlAndListItemBody {
        public string Icon { get; set; }
        public string HtmlContent { get; set; }
        public ISQAListItem[] ListItems { get; set; }
    }
    public class SQAListItem : ISQAListItem {
        public string Text { get; set; }
        public string Target { get; set; }
        public string Url { get; set; }
    }

    public class SQAQuestionAndAnswerBody : ISQAQuestionAndAnswerBody {
        public string Icon { get; set; }
        public ISQAQuestionAndAnswer[] QuestionAndAnswers { get; set; }
    }
    public class SQAQuestionAndAnswer : ISQAQuestionAndAnswer {
        public string Question { get; set; }
        public string Answer { get; set; }
    }

}
