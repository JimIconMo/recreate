﻿using IR.Dependency;

namespace IR.Entities
{
    public class LinkNoIcon : ILinkNoIcon
    {
        public LinkNoIcon() { }
        public string Url { get; set; }
        public string Text { get; set; }
        public LinkNoIcon(string url, string text)
        {
            Text = text;
            Url = url;
        }
    }

}