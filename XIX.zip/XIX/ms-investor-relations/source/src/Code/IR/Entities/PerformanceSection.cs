﻿using System;
using System.Collections.Generic;
using IR.Dependency;

namespace IR.Entities
{
    public class PerformanceSection : EarningsSection, ISection, ISectionWithSegments<IContent>
    {
        public Dictionary<string,IContent> LoadSegments()
        {
            //var xdoc = XDocument.Load(ContentUrl);
            //return xdoc.Descendants("Content")
            //    .Select(xe => (IContent)new Content(xe))
            //    .ToDictionary<IContent, string>(c => c.Segment);
            throw new Exception("'CONTENT!'");
        }
    }
}