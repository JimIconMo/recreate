﻿using System.Xml.Linq;
using IR.Dependency;

namespace IR.Entities
{
    public class Content : IContent
    {
        public IContent From(XElement ele)
        {
            return new Content()
            {
                Segment = ele.Attribute("Segment").Value,
                Heading = ele.ValueOrDefault("Heading") //Items = xe.Element("List").Elements("Item").Select(x => (string)x).ToArray();
            };
        }
        public string Segment { get; set; }
        public string Heading { get; set; }
        public string[] Items { get; set; }

        public override string ToString()
        {
            return Segment;
        }
    }
}