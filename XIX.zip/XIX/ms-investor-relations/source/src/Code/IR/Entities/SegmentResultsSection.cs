﻿using System.Collections.Generic;
using System.Linq;
using IR.Dependency;

namespace IR.Entities
{
    public class SegmentResultsSection : EarningsSection, ISection, ISectionWithSegments<string>
    {
        IEnumerable<string> Segments { get; set; }

        public Dictionary<string,string> LoadSegments()
        {
            return Segments.ToDictionary<string, string>(s => s);
        }
    }
}