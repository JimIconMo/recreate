﻿using IR.Dependency;

namespace IR.Entities
{
    public class Link : ILink
    {
        public string Text { get; set; }
        public string IconUrl { get; set; }
        public string LinkUrl { get; set; }
    }
}