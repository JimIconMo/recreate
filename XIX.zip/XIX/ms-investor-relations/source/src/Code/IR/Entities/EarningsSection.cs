﻿using IR.Dependency;

namespace IR.Entities
{
    public class EarningsSection : ISection
    {
        public SectionsEnum Key { get; set; }
        public string Name { get; set; }
        public string ContentUrl { get; set; }
        public ILink[] Links { get; set; }

    }
}