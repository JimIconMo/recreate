﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using IR.Dependency;

namespace IR.Entities
{
    public class Event : IEvent, IFamSegment
    {
        public string EventID { get; set; }
        public string Name { get; set; }
        public string EventType { get; set; }
        public string[] Segments { get; set; }
        public DateTime Date { get; set; }
        public int FiscalYear { get; set; }
        public string Location { get; set; }
        public string Speaker { get; set; }
        public string Title { get; set; }
        public string Dept { get; set; }
        private string _thumbnailUrl = null;
        public string ThumbnailUrl 
        {
            get { return (_thumbnailUrl ?? "").Replace("(", "%28").Replace(")", "%29"); } //problematic for css url()
            set { _thumbnailUrl = value;} 
        }
        public string ThumbnailAltText { get; set; }
        public ILink[] Links { get; set; }
        public int LinkCount
        {
            get
            {
                int cnt = Links.Count();
                return ((cnt==0 || string.IsNullOrWhiteSpace(Links.First().Text)) ? 0 : cnt);
            }
        }
        public bool Featured { get { return "earnings".Equals(EventType, StringComparison.OrdinalIgnoreCase); } }
        public string MobileWebcast { get; set; }
        public static IEnumerable<IEvent> From<X>(X x) where X : IEnumerable<XElement> {
            return x.Select(ele => From(ele));
        }
        public static IEvent From(XElement ele)
        {
            return new Event() {
                    EventID          = ele.ValueOrDefault("EventID"),
                    Name             = ele.ValueOrDefault("EventName"),
                    EventType        = ele.ValueOrDefault("EventType"),
                    Segments         = ele.Element("Tags").Elements("Tag").Select(t => t.ValueOrDefault("Tag")).ToArray(),
                    Date             = ele.ValueOrDefault<System.DateTime>("DateTime/UTC"),
                    FiscalYear       = ele.ValueOrDefault<int>("FiscalYear"),
                    Location         = ele.ValueOrDefault("Location"),
                    Speaker          = ele.ValueOrDefault("Speaker/Name"),
                    Title            = ele.ValueOrDefault("Speaker/Position"),
                    Dept             = ele.ValueOrDefault("Speaker/Department"),
                    ThumbnailUrl     = ele.ValueOrDefault("ThumbnailImage/Url"),
                    ThumbnailAltText = ele.ValueOrDefault("ThumbnailImage/AltText"),
                    Links            = ele.Element("RecentLinks").Elements("Link").Select(link => new Link() {
                        Text         = link.ValueOrDefault("Text"), 
                        IconUrl      = link.ValueOrDefault("Icon"), 
                        LinkUrl      = link.ValueOrDefault("Url")
                    }).ToArray(),
                    MobileWebcast    = ele.ValueOrDefault("MobileWebcast")
            };
        }
    }
    public class EventList : IEnumerable<IEventList>, IEventList, IEnumerable<IEvent>
    {
        public string[] EventTypes { get; set; }
        public string[] EventSegments { get; set; }
        public string[] Speakers { get; set; }
        public int[] Years { get; set; }
        public EventList() : base() {
            EventTypes = new string[0];
            EventSegments = new string[0];
            Speakers = new string[0];
            Years = new int[0];
        }
        public int Count { get; set; }
        public static IEnumerable<IEventList> GetFrom(IEnumerable<IEvent> full) {
            return new IEventList[] { new EventList()
            {
                EventTypes = full.Select(evt => evt.EventType).Distinct().ToArray(),
                EventSegments = full.SelectMany(evt => evt.Segments).Distinct().ToArray(),
                Speakers = full.Where(evt => !string.IsNullOrWhiteSpace(evt.Speaker)).Select(evt => evt.Speaker).Distinct().ToArray(),
                Years = full.Select(evt => evt.Date.Year).Distinct().ToArray()
            }
            }.Select(e => (IEventList)e).AsEnumerable<IEventList>();
        }


        public IEnumerator<IEventList> GetEnumerator()
        {
            yield return (IEventList)this;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        IEnumerator<IEvent> IEnumerable<IEvent>.GetEnumerator()
        {
            yield return (IEvent)this;
        }
    }
}