﻿using System;
using System.Web.Configuration;

namespace IR
{
    public class BasePage : System.Web.UI.Page
    {
        public string DataError { get; set; }
        public string EscapeUrl(string url = null) {
            return Uri.EscapeDataString(Page.ResolveClientUrl(url ?? Request.FilePath));
        }
        public string EscapeUrl(string fmt, string url) {
            return string.Format(fmt, EscapeUrl(Page.ResolveClientUrl(url ?? Request.FilePath)));
        }
        public string GetAppSetting(string key) {
            return WebConfigurationManager.AppSettings[key];
        }
        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            DataBind();
        }
        protected override void OnDataBinding(EventArgs e) {
            base.OnDataBinding(e);
            (((IR.Shared.Site)Master).DataController).Print(">>> BasePage_OnDataBinding() data-controller is set to '{0}'.");
        }
        protected override void OnError(EventArgs e) {
            base.OnError(e);
            this.DataError = "An error has occurred.".Print();
        }
    }
}