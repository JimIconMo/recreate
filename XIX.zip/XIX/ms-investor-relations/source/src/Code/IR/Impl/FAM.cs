﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using System.Xml;

namespace IR.Impl
{
}
public class IRAnalystMeeting
{
    public IEnumerable<IR.Dependency.ILinkNoIcon> Links
    {
        get
        {
            if (this.Links is XmlNode[]) 
                foreach(var k in IR.Entities.FAM.ExtractLinks((XmlNode[])this.Links)) 
                    yield return k;
            
            //else if (this.SubTitle is string)
            //    yield return (IR.Dependency.ILinkNoIcon)new IR.Entities.LinkNoIcon((string)this.SubTitle, "");
        }
    }
}
