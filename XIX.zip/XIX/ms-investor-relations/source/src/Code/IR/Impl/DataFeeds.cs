﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Configuration;
using System.Xml.Linq;
using System.Xml.Serialization;
using IR.Dependency;
using IR.Entities;

namespace IR.Impl {
    public class DataFeeds : IDataFeeds {
        string DataHost(Feeds feed) { return DataHost(feed.ToString()); }
        string DataHost(string item = "") {
            var sets = WebConfigurationManager.AppSettings;
            return string.Format(sets["DataForm"], sets["DataHost"], item);
        }

        string MSIRHost(string item = "") {
            var sets = WebConfigurationManager.AppSettings;
            return string.Format(sets["MSIRForm"], sets["MSIRHost"], item);
        }

        public IEnumerable<T> GetCache<T>(string key = null, Func<string,IEnumerable<T>> get = null) {
            key = key ?? typeof(T).Name;
            var obj = HttpContext.Current.Cache[key];
            if (obj == null && get != null) HttpContext.Current.Cache.Add(key,
                obj = get(key), null, System.Web.Caching.Cache.NoAbsoluteExpiration,
                new TimeSpan(1, 0, 0), System.Web.Caching.CacheItemPriority.AboveNormal, null);
            return (IEnumerable<T>)obj;
        }
        public IEnumerable<T> GetCache<T>(Feeds feed, Func<string,IEnumerable<T>> get = null) { return GetCache(DataHost(feed), get); }
        public IEnumerable<T> GetCache<T>(Func<string,IEnumerable<T>> get = null) { return GetCache(null, get); }
        public T GetCache<T>(string key = null, Func<string,T> get = null) {
            key = key ?? typeof(T).Name;
            var obj = HttpContext.Current.Cache[key];
            if (obj == null && get != null) HttpContext.Current.Cache.Add(key,
                obj = get(key), null, System.Web.Caching.Cache.NoAbsoluteExpiration,
                new TimeSpan(1, 0, 0), System.Web.Caching.CacheItemPriority.AboveNormal, null);
            return (T)obj;
        }
        public T GetCache<T>(Feeds feed, Func<string,T> get = null) { return GetCache(DataHost(feed), get); }
        public T GetCache<T>(Func<string,T> get = null) { return GetCache(null, get); }
        public IEnumerable<T> Get<T>() {
            Func<string,IEnumerable<XElement>> xel = url => {
                try { 
                    return XElement.Load(url).Elements();
                } catch (Exception ex) {
                    ex.Print(">>> Error loading xml from {1}: {0}", url);
                    return XElement.EmptySequence;
                }
            };
            Func<string> sds = () => {
                string url = "";
                try {
                    return string.Concat(GetCache(Feeds.StaticDataSource, key => new WebClient().DownloadString(url=key)));
                } catch (Exception ex) {
                    ex.Print(">>> Error loading content from {1}: {0}", url);
                    return "<error />";
                }
            };
            switch (typeof(T).Name) {
                case "IEvent":
                    return GetCache(Feeds.Events, key => Event.From(xel(key)).OrderByDescending(d=>d.Date)).Cast<T>();
                case "IEventList":
                    IEnumerable<IEvent> full = GetCache(Feeds.Events, key => Event.From(xel(key)));
                    return GetCache("EventList", key => new EventList() {
                        EventSegments = full.SelectMany(i => i.Segments).Distinct().ToArray(),
                        EventTypes    = full.Select(i => i.EventType).Distinct().ToArray(),
                        Years         = full.Select(i => i.Date.Year).Distinct().ToArray(), //TODO: consider using FiscalYear?
                        Speakers      = full.Where(i => !string.IsNullOrWhiteSpace(i.Speaker)).Select(i => i.Speaker).Distinct().ToArray()
                    }).ToEnumerable().Cast<T>();
                //case "IFAM":
                    //new Event(){Speaker=seg.Speaker.Name, Title=seg.Speaker.Position, ThumbnailUrl=seg.ThumbnailImage.Url, ThumbnailAltText=seg.ThumbnailImage.AltText,
                    //                Links=seg.LinkItems.Select(l => new Link(l.Text, l.Icon, l.Url)).ToArray()
                    //public IFAM GetFamData(int year)
                    //{
                    //    string suffix = year.ToString(); //year == 0 || year == DateTime.Today.Year - 1 ? "" : year.ToString();
                    //    string url = DataHost("FAM" + suffix);
                    //    var result = GetCache(url, () => Deserialize<global::IRAnalystMeeting>(url));
                    //    return FAM.GetFromDeserializedObject(result);
                    //}
                    //break;
                case "IAnnouncement":
                    var els = Announcement.From(xel(DataHost(Feeds.Announcements)));
                    return GetCache(Feeds.Announcements, key => Announcement.From(xel(key))).Cast<T>();
                case "ISQAFeed":
                    return GetCache(Feeds.StockSplit, key => SQAFeed.From(xel(key))).Cast<T>();
                case "ICGSection":
                    return GetCache(Feeds.CGOverview, key => CGOverview.From(xel(key))).Cast<T>();
                case "IAnnualReport":
                    return GetCache(Feeds.AnnualReportQuickLink, key => AnnualReport.From(XElement.Load(key).ToEnumerable())).Cast<T>();
                case "IHomeTiles":
                    return GetCache("IHomeTiles", key => HomeTiles.From(XElement.Parse(sds()).ToEnumerable())).Cast<T>();
                case "IEarnings<SectionsEnum>":
                    return GetCache("IEarnings<SectionsEnum>", key => EarningsReleases.From(XElement.Parse(sds()).ToEnumerable())).Cast<T>();
                default:
                    throw new NotImplementedException();
            }
        }
    }
}