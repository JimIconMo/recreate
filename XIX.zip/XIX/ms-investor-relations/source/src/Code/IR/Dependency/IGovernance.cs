﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public interface IHeader
    {
        string ImageUrl { get; }
        string AltText { get; }
        string Text { get; }
    }

    public interface ILinkItem
    {
        string Title { get; }
        ILinkNoIcon[] Links { get; }
    }

    public interface ICGSection
    {
        IHeader Header { get; }
        ILinkItem[] LinkItems { get; }
    }

    public interface ICGOverview 
    {
        ICGSection CorporateGovernance { get; }
        ICGSection CorporateCitizenship { get; }
    }
}
