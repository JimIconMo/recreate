﻿namespace IR.Dependency {
    public interface ISQAFeed
    {
        string StockSplitTitle { get; }
        ISQAContent[] StockSplitContents { get; }
    }
    public interface ISQAContent
    {
        string ContentTitle { get; }
        string HtmlBody { get; }
        ISQAListItemBody ListItemBody { get; }
        ISQAHtmlAndListItemBody HtmlAndListItemBody { get; }
        ISQAQuestionAndAnswerBody QuestionAndAnswerBody { get; }
        string type { get; }
    }

    public interface ISQAListItemBody
    {
        string Icon { get; }
        ISQAListItem[] ListItems { get; }
    }

    public interface ISQAHtmlAndListItemBody
    {
        string Icon { get; }
        string HtmlContent { get; }
        ISQAListItem[] ListItems { get; }
    }

    public interface ISQAListItem
    {
        string Text { get; }
        string Target { get; }
        string Url { get; }
    }

    public interface ISQAQuestionAndAnswerBody
    {
        string Icon { get; }
        ISQAQuestionAndAnswer[] QuestionAndAnswers { get; }
    }

    public interface ISQAQuestionAndAnswer
    {
        string Question { get; }
        string Answer { get; }
    }
}