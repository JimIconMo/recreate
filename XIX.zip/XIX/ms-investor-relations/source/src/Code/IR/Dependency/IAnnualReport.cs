﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    namespace AnnualReports
    {
        public enum ImageTypes { ThumbnailDesktop = 0, ThumbnailMobile = 1, FullDesktop = 2, FullMobile = 3 };
        public enum LinkTypes { FullDesktop = 0, Download = 1 };
    }

    public interface IAnnualReport
    {
        string Title { get; }
        string ThumbnailImage_AltText { get; }
        string ThumbnailImage_Url { get; }
        string ThumbnailImageForMobile_AltText { get; }
        string ThumbnailImageForMobile_Url { get; }
        string EnlargedImage_AltText { get; }
        string EnlargedImage_Url { get; }
        string EnlargedImageForMobile_AltText { get; }
        string EnlargedImageForMobile_Url { get; }
        string HttpLink_Target { get; }
        string HttpLink_AltText { get; }
        string HttpLink_Url { get; }
        string DownloadLink_Target { get; }
        string DownloadLink_AltText { get; }
        string DownloadLink_Url { get; }
        string MoreImages { get; }
        bool BeforeAnnualReport { get; }
        Dictionary<AnnualReports.ImageTypes, IImage> Images { get; }
        Dictionary<AnnualReports.LinkTypes, ILinkNoIcon> Links { get; }

    }
}
