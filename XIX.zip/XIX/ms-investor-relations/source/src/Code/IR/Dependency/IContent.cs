﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public interface IContent
    {
        string Segment { get; }
        string Heading { get; }
        string[] Items { get; }
    }
}
