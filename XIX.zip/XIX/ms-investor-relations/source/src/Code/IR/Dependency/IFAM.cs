﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public interface IFAM
    {
        string Title { get; }
        string Subtitle { get; }
        IImage BannerImage { get; }
        IEnumerable<ILinkNoIcon> HeaderLinks { get; }

        IEnumerable<IEvent> Segments { get; }
    }
}
