﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public interface IEarnings<T>
    {
        IDictionary<T,ISection> Sections { get; }
    }
}
