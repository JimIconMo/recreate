﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public enum SectionsEnum { press = 0, statements = 1, performance = 2, kpi = 3, segment = 4 };

    public interface ISection
    {
        SectionsEnum Key { get; }
        string Name { get; }
        string ContentUrl { get; }
        ILink[] Links { get; }
    }
}
