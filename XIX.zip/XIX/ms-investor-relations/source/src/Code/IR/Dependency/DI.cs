﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using IR.Impl;
using System.Xml.Linq;

namespace IR.Dependency {
    public enum Feeds {
        None,
        AnnualMeeting,
        Announcements,
        AnnualReportQuickLink,
        CGOverview,
        Events,
        FAM,
        IRHero,
        StaticDataSource,
        StockSplit
    }
    public class DI
    {
        public static TInterface Get<TInterface>() //where TInterface : <interface>
        {
            Type t = typeof(TInterface);
            if (t == typeof(IDataFeeds))
            {
                return (TInterface)(IDataFeeds)new DataFeeds();
            }

            throw new NotImplementedException();
        }
    }
}