﻿namespace IR.Dependency
{
    public interface IEvent
    {
        string EventID { get; }
        string Name { get; }
        string EventType { get; }
        string[] Segments { get; }
        System.DateTime Date { get; }
        int FiscalYear { get; }
        string Location { get; }
        string Speaker { get; }
        string Title { get; }
        string Dept { get; }
        string ThumbnailUrl { get; }
        string ThumbnailAltText { get; }
        ILink[] Links { get; }
        string MobileWebcast { get; }
        int LinkCount { get; }
        bool Featured { get; }
    }
    public interface IEventList
    {
        string[] EventTypes { get;}
        string[] EventSegments { get; }
        string[] Speakers { get; }
        int[] Years { get; }
        int Count { get; }
    }
}
