﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IR.Dependency
{
    public interface ILinkNoIcon
    {
        string Text { get; }
        string Url { get; }
    }
}