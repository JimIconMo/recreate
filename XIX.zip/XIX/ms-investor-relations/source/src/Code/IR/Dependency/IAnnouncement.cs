﻿namespace IR.Dependency
{
    public interface IAnnouncement
    {
        string EntryID { get; }
        bool Active { get; }
        bool ActiveSpecified { get; }
        System.DateTime CreateTime { get; }
        bool CreateTimeSpecified { get; }
        string ExpirationTime { get; }
        string DisplayOrder { get; }
        string Header1 { get; }
        string Header2 { get; }
        string Header3 { get; }
        bool CheckToEdit { get; }
        bool CheckToEditSpecified { get; }
        IAnnouncementDateTime DateTime { get; }
        IAnnouncementLink[] Links { get; }
    }
    public interface IAnnouncementDateTime
    {
        System.DateTime UTC { get; }
        bool UTCSpecified { get; }
        System.DateTime Local { get; }
        bool LocalSpecified { get; }
        string TimeZone { get; }
    }
    public interface IAnnouncementLink
    {
        string Text { get; }
        string Icon { get; }
        string URL { get; }
        string OpenMode { get; }
    }
}