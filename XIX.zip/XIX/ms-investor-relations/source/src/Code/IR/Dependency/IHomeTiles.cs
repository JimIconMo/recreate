﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public interface IHomeTiles
    {
        string ERHeader { get; }
        string EarningsEventID { get; }
        string AnnualMeetingID { get; }
        string PRHtml { get; }
        string PRDocx { get; }
        string FinancialStatementXlsx { get; }
        string PerformanceContentXml { get; }
        string ICXml { get; }
        string KPIXlsx { get; }
        string CommitteesHtm { get; }
        string FactSheetHtm { get; }
        IEarnings[] Earnings { get; }
        ISegmentName[] SegmentNames { get; }
        ICorp Corporate { get; }
        string EarningsHeadline  { get; }
    }
    public interface IEarnings
    {
        string ItemId { get; }
        string SectionName { get; }
    }

    public interface ISegmentName
    {
        string Order { get; }
        string Name { get; }
        string PerformanceTag { get; }
        string ICTag { get; }
    }

    public interface ICorp
    {
        string Name { get; }
        string PerformanceTag { get; }
        string ICTag { get; }
    }

}
