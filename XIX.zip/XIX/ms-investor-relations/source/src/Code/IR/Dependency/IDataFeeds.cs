﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace IR.Dependency {
    public interface IDataFeeds {
        IEnumerable<T> Get<T>();
        IEnumerable<T> GetCache<T>(string key = null, Func<string, IEnumerable<T>> get = null);
        IEnumerable<T> GetCache<T>(Feeds feed, Func<string, IEnumerable<T>> get = null);
        T GetCache<T>(string key = null, Func<string, T> get = null);
        T GetCache<T>(Feeds feed, Func<string, T> get = null);
        //IFAM GetFamData(int year);
    }
}
