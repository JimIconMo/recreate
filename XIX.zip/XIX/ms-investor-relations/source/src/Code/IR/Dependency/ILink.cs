﻿namespace IR.Dependency
{
    public interface ILink
    {
        string Text { get; }
        string IconUrl { get; }
        string LinkUrl { get; }
    }
}