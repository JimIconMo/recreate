﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IR.Dependency
{
    public interface IFamSegment
    {
        string Name { get; }
        
        string Speaker { get; }
        
        string Title { get; }

        string ThumbnailUrl { get; }
        string ThumbnailAltText { get; }

        ILink[] Links { get; }
        int LinkCount { get; }
    }
}
