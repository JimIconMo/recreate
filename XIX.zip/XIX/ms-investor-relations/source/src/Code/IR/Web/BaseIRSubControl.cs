﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IR.Web {
    public class BaseIRSubControl : System.Web.UI.UserControl {

        public BasePage PageBase { get { return ((BasePage)Page); } }
        public string DataError { 
            get { return PageBase.DataError; } 
            set { PageBase.DataError = value; } 
        }
        public string EscapeUrl(string url = null) {
            return PageBase.EscapeUrl(url);
        }
        public string EscapeUrl(string fmt, string url) {
            return PageBase.EscapeUrl(fmt, url);
        }
        public string GetAppSetting(string key) {
            return PageBase.GetAppSetting(key);
        }

    }
}