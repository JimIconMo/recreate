﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IR.Web
{
    public class TemplateItem : Control, INamingContainer
    {
        private String _message = null;

        public TemplateItem(String message)
        {
            _message = message;
        }

        public String Message
        {
            get { return _message; }
            set { _message = value; }
        }
    }

    [ParseChildren(true)]
    public class SegmentControl : BaseIRControl<IEnumerable<string>>, INamingContainer
    {
        private ITemplate _header = null;
        private String _message = null;

        public String Message
        {
            get { return _message; }
            set { _message = value; }
        }

        [PersistenceMode(PersistenceMode.InnerProperty), TemplateContainer(typeof(TemplateItem))]
        public ITemplate HeaderCml
        {
            get { return _header; }
            set { _header = value; }
        }

        protected override void CreateChildControls()
        {

            // If a template has been specified, use it to create children.
            // Otherwise, create a single LiteralControl with the message value.

            if (HeaderCml != null)
            {
                TemplateItem i = new TemplateItem(this.Message);

                if (HeaderCml != null) HeaderCml.InstantiateIn(i);

                Control header = (PlaceHolder)this.FindControl("HeaderPlaceholder");
                header.Controls.Add(i);
                header.DataBind();
            }
            else
            {
                this.Controls.Add(new LiteralControl(this.Message));
            }
        }
    }
}