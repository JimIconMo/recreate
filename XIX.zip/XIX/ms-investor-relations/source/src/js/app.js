﻿$(document).ready(function () {
    /* Events navigation
    $("body").bind("click", function (e) {
    var el = $(e.target);
    var role = el.attr('role');
    if (role == "more") {
    el.closest(".event").animate({ "margin-left": "-600px" });
    } else if (role == "less") {
    el.closest(".event").animate({ "margin-left": 0 });
    }
    });
    */
    var setupTiles = function () {
        var paneWidth = $(window).width();
        //$("#menu").css("left", paneWidth+'px');

        /* setup tile widths */
        (function (w) {
            var tileW = $(".tile.normal").eq(0).width();
            $(".tile").css('height', tileW);
        })(paneWidth);
    }
    setupTiles();
    $(window).resize(setupTiles);

    /* setup click handler */
    $("body").bind("click", function (e) {
        var el = $(e.target);
        var role = el.attr('role');
        var state = el.attr('state');
        var newstate = (state == "back" ? "menu" : "back");
        if (role == 'menu') {
            $("#container").animate({ marginLeft: (state == "back") ? "" : "-90%" }, 600);
            $(e.target).toggleClass("selected");
            $(e.target).parent().find("span").text(newstate);
            $(e.target).attr('state', newstate);
        } else if (role == "more") {
            el.closest(".event").animate({ "margin-left": "-95%" });
        } else if (role == "less") {
            el.closest(".event").animate({ "margin-left": 0 });
        } else if (role == "featured-more") {
            el.closest(".slide").animate({ "margin-left": "-50%" });
        } else if (role == "featured-less") {
            el.closest(".slide").animate({ "margin-left": 0 });
        } else if (role == "filter") {
            $("#filters").slideToggle();
            $("#filter-toggle").toggleClass("flipy");
        }

    });

    /* setup live tiles */
    (function (el) {
        if (el.length == 0) return;
        function reverse(e) {
            if (el.data('wait') === false) {
                var reverse = el.data('reverse');
                el.data('reverse', el.html());
                el.html(reverse);
                el.toggleClass('flip');
                el.data('wait', true);
            }
        }
        el[0].addEventListener('webkitTransitionEnd', reverse);
        el[0].addEventListener('transitionend', reverse);

        el.data('reverse', 'Stock price');
        setInterval(function () {
            el.toggleClass('flip');
            el.data('wait', false);
        }, 5000);
    })($('.tile:eq(1)'));
    (function (el) {
        if (el.length == 0) return;
        var i = 0;
        var offset = ["-100px", "-50px", 0];
        function scroll() {
            i++;
            if (i >= offset.length) i = 0;
            el.find(".content").animate({ "margin-top": offset[i] });
        }
        var i = setInterval(scroll, 5000);
    })($(".tile:eq(0)"));

    (function setup() {
        var effects = [
			{ "background-image": "url('http://lorempixel.com/180/180/people/9/')" },
			{ "background-image": "url('http://lorempixel.com/180/180/people/7/')" },
			{ "background-image": "", "background-color": "#7777FF" }
		];
        (function setup() {
            var items = $(".sub");
            var options = { "background-size": "300% 300%" };
            var lrpos = ["left", "center", "right"];
            var tbpos = ["top", "center", "bottom"];
            var cnt = 0;
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    options["background-position"] = lrpos[j] + " " + tbpos[i];
                    var r = Math.ceil(Math.random() * 3) - 1;
                    $(items[cnt]).css($.extend(options, effects[r])).data({ index: 0, flipped: false });
                    cnt++;
                }
            }
            $(".sub").each(function (i, e) {
                e.addEventListener('webkitTransitionEnd', reverse(e));
            });

            $("#container").click(function (e) { toggle($(e.target)); });
        })();

        function reverse(el) {
            return function () {
                var flipped = $(el).data('flipped');
                if (flipped != true) {
                    var idx = $(el).data('index');
                    $(el).toggleClass("flip");
                    $(el).css(effects[idx]);
                }
                $(el).data('flipped', !flipped);
            }
        }
        var r1 = 0, r2 = 0;
        var el = $(".sub[data-row=" + r1 + "][data-column=" + r2 + "]").eq(0);
        if (el.length != 0) {
            function toggle(el) {
                if (el[0].className == "sub") {
                    var idx = el.data('index');
                    idx++;
                    if (idx >= effects.length) idx = 0;
                    el.toggleClass("flip");
                    el.data('index', idx);
                }
            }
            var i = setInterval(function () {
                r1 = Math.ceil(Math.random() * 3) - 1;
                r2 = Math.ceil(Math.random() * 3) - 1;
                toggle(el);
            }, 2000);
        }
    })();
});
var IR = IR || {};
IR.reset = function (e) {
    $(e).find('input').each(function () { this.value = ''; });
    $(e).find('select').each(function () { this.selectedIndex=0; });
}
IR.rx_email = /^(?:[\w!#$%&'*+\/=?^_`{|}~-]+(?:\.[\w!#$%&'*+\/=?^_`{|}~-]+)*@(?:\w(?:[\w-]*\w)?\.)+\w(?:[\w-]*\w)?)$/;
IR.reminder = function (btn) {
    var a = $(btn.parentElement),
        b = $(btn).unbind('click').attr('onclick','').html('email:&nbsp;<input type="text" class="reminder-email" />'),
        c = a.children('.reminder-name'),
        d = a.children('.reminder-date'),
        e = b.children('input'),
        f = function (jev) {
            var val = e.val();
            if ((jev.keyCode == 13 || jev.keyCode == 9) && IR.rx_email.test(val)) {
                $.ajax({
                    url: 'Events.aspx/GetNotification',
                    type: 'POST',
                    data: JSON.stringify({
                        rem_email: val,
                        rem_event: c.text(),
                        rem_ticks:+d.attr('class').split(/\bticks-(\d+)/, 2)[1]
                    }),
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    complete: function (jev, ok) {
                        b.html(ok == "success" ? "Get another notification" : "Try again later");
                        b.click(function () { IR.reminder(b[0]); });
                    }
                });
                b.html('working...');
            }
        };
    e.keydown(f).focusout(f);
    setTimeout(function () { e.focus(); }, 1);
}
